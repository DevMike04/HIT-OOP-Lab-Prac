public class Animal {
    public void sound() {
        System.out.println("Animal makes a generic sound.");
    }
}

class Cat extends Animal {
    @Override
    public void sound() {
        System.out.println("Cat says: Meow");
    }
}

class Cow extends Animal {
    @Override
    public void sound() {
        System.out.println("Cow says: Moo");
    }
}

class Duck extends Animal {
    @Override
    public void sound() {
        System.out.println("Duck says: Quack");
    }
}

class AnimalTest {
    public static void main(String[] args) {
        // Storing different subclasses in a polymorphic Animal array
        Animal[] animals = {
                new Cat(),
                new Cow(),
                new Duck(),
                new Animal()
        };

        // Looping and calling sound() polymorphically
        for (Animal animal : animals) {
            animal.sound(); // Dispatches to the correct subclass implementation at runtime
        }
    }
}
