abstract class Employee {
    String name;

    public Employee(String name) {
        this.name = name;
    }

    // Abstract method forcing subclasses to define their own payment logic
    public abstract double calculatePay();
}

class FullTimeEmployee extends Employee {
    private double monthlySalary;

    public FullTimeEmployee(String name, double monthlySalary) {
        super(name);
        this.monthlySalary = monthlySalary;
    }

    @Override
    public double calculatePay() {
        return monthlySalary;
    }
}

class PartTimeEmployee extends Employee {
    private double hourlyRate;
    private int hoursWorked;

    public PartTimeEmployee(String name, double hourlyRate, int hoursWorked) {
        super(name);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double calculatePay() {
        return hourlyRate * hoursWorked;
    }
}

// Newly added Intern subclass
class Intern extends Employee {
    private double stipend;

    public Intern(String name, double stipend) {
        super(name);
        this.stipend = stipend;
    }

    @Override
    public double calculatePay() {
        return stipend;
    }
}

class PayrollTest {
    public static void main(String[] args) {
        // Mixed array of employees
        Employee[] employees = {
                new FullTimeEmployee("Alice", 5000.0),
                new PartTimeEmployee("Bob", 25.0, 80),
                new Intern("Charlie", 1200.0)
        };

        double totalPayroll = 0;

        // The payroll loop remains completely untouched regardless of new subclasses
        for (Employee emp : employees) {
            double pay = emp.calculatePay();
            System.out.println(emp.name + " pay: $" + pay);
            totalPayroll += pay;
        }

        System.out.println("Total Company Payroll: $" + totalPayroll);
    }
}
