// Approach 1: Procedural with instanceof Pattern Matching
public interface Payment {}

    class CardPayment implements Payment {
        double amount;

        public CardPayment(double amount) {
            this.amount = amount;
        }
    }

    class MobileMoneyPayment implements Payment {
        double amount;

        public MobileMoneyPayment(double amount) {
            this.amount = amount;
        }
    }

    class PaymentProcessorProcedural {
        public void pay(Payment p) {
            // Using Java instanceof pattern matching
            if (p instanceof CardPayment cp) {
                System.out.println("Processing credit card payment of $" + cp.amount);
            } else if (p instanceof MobileMoneyPayment mp) {
                System.out.println("Processing mobile money payment of $" + mp.amount);
            } else {
                throw new IllegalArgumentException("Unknown payment type");
            }
        }
    }

