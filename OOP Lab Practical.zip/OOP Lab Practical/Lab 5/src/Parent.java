public class Parent {
    String name = "Parent Field";

    public void display() {
        System.out.println("Parent Method");
    }
}

class Child extends Parent {
    String name = "Child Field"; // Shadows parent field

    @Override
    public void display() {
        System.out.println("Child Method");
    }
}

class ShadowingVsOverrideTest {
    public static void main(String[] args) {
        Parent ref = new Child(); // Superclass reference pointing to subclass object

        // 1. Field access is resolved based on the REFERENCE type (Parent)
        System.out.println("Accessed via field: " + ref.name); // Output: Parent Field

        // 2. Method call is resolved dynamically based on the OBJECT type (Child)
        ref.display(); // Output: Child Method
    }
}
// In Java, methods are polymorphic (resolved dynamically at runtime based on the object type), whereas fields are non-polymorphic (resolved statically at compile-time based on the reference type).

/* Why does this happen?

Methods use Dynamic Method Dispatch: Java looks up the actual object instance in heap memory at runtime to decide which method version to execute.

Fields use Static Binding: Field access is determined purely by the declared type of the variable at compile-time, resulting in field shadowing rather than overriding.

                                     */