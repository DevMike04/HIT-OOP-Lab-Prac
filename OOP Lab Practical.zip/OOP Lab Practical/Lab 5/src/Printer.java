public class Printer {
    public void print(int val) {
        System.out.println("Printing int: " + val);
    }

    // Overloaded method for double
    public void print(double val) {
        System.out.println("Printing double: " + val);
    }

    // Overloaded method for String
    public void print(String val) {
        System.out.println("Printing String: " + val);
    }

    // Overloaded method for int array
    public void print(int[] val) {
        System.out.print("Printing int[]: ");
        for (int num : val) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

class OverloadTest {
    public static void main(String[] args) {
        Printer printer = new Printer();

        printer.print(42);              // Calls int version
        printer.print(3.14159);         // Calls double version
        printer.print("Hello, Java!");  // Calls String version
        printer.print(new int[]{1, 2, 3, 4, 5}); // Calls int[] version
    }
}
