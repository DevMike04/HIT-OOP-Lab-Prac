// Approach 2: Pure Polymorphism (Recommended OOP Design)

interface PolymorphicPayment {
    void process();
}

class CardPaymentPoly implements PolymorphicPayment {
    double amount;
    public CardPaymentPoly(double amount) { this.amount = amount; }

    @Override
    public void process() {
        System.out.println("Processing credit card payment of $" + amount);
    }
}

class MobileMoneyPaymentPoly implements PolymorphicPayment {
    double amount;
    public MobileMoneyPaymentPoly(double amount) { this.amount = amount; }

    @Override
    public void process() {
        System.out.println("Processing mobile money payment of $" + amount);
    }
}

class PaymentProcessorPolymorphic {
    public void pay(PolymorphicPayment p) {
        p.process(); // Delegates completely without knowing concrete types
    }
}
