import java.time.LocalDate;

public class CarWithAntique {
    String brand;
    int year;
    double mileage;

    public CarWithAntique(String brand, int year, double mileage) {
        this.brand = brand;
        this.year = year;
        this.mileage = mileage;
    }

    public void display() {
        System.out.println("Brand: " + brand + ", Year: " + year + ", Mileage: " + mileage + " miles");
    }

    // Returns true if the car is more than 25 years old
    public boolean isAntique() {
        int currentYear = LocalDate.now().getYear();
        return (currentYear - year) > 25;
    }
}

class AntiqueTest {
    public static void main(String[] args) {
        CarWithAntique car1 = new CarWithAntique("Toyota", 2018, 45000.5);
        CarWithAntique car2 = new CarWithAntique("Classic Ford Mustang", 1995, 150000.0);

        System.out.println(car1.brand + " is antique? " + car1.isAntique());
        System.out.println(car2.brand + " is antique? " + car2.isAntique());
    }
}
