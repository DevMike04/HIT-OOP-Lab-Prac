public class Car {
        String brand;
        int year;
        double mileage;

        // Constructor to initialize Car fields
        public Car(String brand, int year, double mileage){
            this.brand = brand;
            this.year = year;
            this.mileage = mileage;
        }

        // Method to display car details
        public void display () {
            System.out.println("Brand: " + brand + ", Year: " + year + ", Mileage: " + mileage + " miles");
        }
    }

 class CarDemo {
    public static void main(String[] args) {
        // Creating three car objects
        Car car1 = new Car("Toyota", 2018, 45000.5);
        Car car2 = new Car("Ford", 1995, 150000.0);
        Car car3 = new Car("Honda", 2022, 12000.0);

        // Printing their details
        car1.display();
        car2.display();
        car3.display();
    }
}