public class Rectangle {
    double width;
    double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double area() {
        return width * height;
    }

    public double perimeter() {
        return 2 * (width + height);
    }
}

class RectangleArrayTest {
    public static void main(String[] args) {
        // Create an array of 5 rectangles
        Rectangle[] rectangles = {
                new Rectangle(4.0, 5.0),   // Area: 20.0
                new Rectangle(10.5, 3.0),  // Area: 31.5
                new Rectangle(7.0, 8.0),   // Area: 56.0 (Largest)
                new Rectangle(2.5, 6.0),   // Area: 15.0
                new Rectangle(5.5, 5.5)    // Area: 30.25
        };

        Rectangle largest = rectangles[0];

        // Iterate to find the rectangle with the largest area
        for (int i = 1; i < rectangles.length; i++) {
            if (rectangles[i].area() > largest.area()) {
                largest = rectangles[i];
            }
        }

        System.out.println("Rectangle with the largest area:");
        System.out.println("Width: " + largest.width + ", Height: " + largest.height);
        System.out.println("Area: " + largest.area());
    }
}
