public class Address {
    String city;
    String street;

    public Address(String city, String street) {
        this.city = city;
        this.street = street;
    }

    public String getCity() {
        return city;
    }
}

class Person {
    String name;
    Address address; // Reference to an Address object

    public Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    public Address getAddress() {
        return address;
    }
}

class ChallengeTest {
    static void main() {
        // 1. Normal case with a valid address
        Address addr = new Address("Harare", "5th Avenue");
        Person p1 = new Person("Mary", addr);

        // Chained dot expression to print city
        System.out.println(p1.name + "'s city: " + p1.getAddress().getCity());

        // 2. Case where address is null (Demonstrating NullPointerException)
        Person p2 = new Person("Bob", null);

        try {
            // This attempts to call .getCity() on a null reference returned by getAddress()
            System.out.println(p2.name + "'s city: " + p2.getAddress().getCity());
        } catch (NullPointerException e) {
            System.out.println("Caught NullPointerException: p2.getAddress() returned null, so invoking .getCity() on it fails.");
        }
    }
}
