public class Temperature {
    private final double kelvin;


        private Temperature(double kelvin) {
            if (kelvin < 0) {
                throw new IllegalArgumentException("Temperature cannot be below absolute zero (0 Kelvin).");
            }
            this.kelvin = kelvin;
        }

        // Static factory methods for intuitive instantiation
        public static Temperature fromKelvin(double kelvin) {
            return new Temperature(kelvin);
        }

        public static Temperature fromCelsius(double celsius) {
            return new Temperature(celsius + 273.15);
        }

        public static Temperature fromFahrenheit(double fahrenheit) {
            double celsius = (fahrenheit - 32) * 5.0 / 9.0;
            return new Temperature(celsius + 273.15);
        }


        public double getKelvin() {
            return kelvin;
        }

        public double getCelsius() {
            return kelvin - 273.15;
        }

        public double getFahrenheit() {
            return (getCelsius() * 9.0 / 5.0) + 32;
        }
    }

    class TemperatureDecouplingTest {
        public static void main(String[] args) {
            Temperature temp = Temperature.fromCelsius(25.0);

            // Callers use Celsius and Fahrenheit seamlessly
            System.out.println("Celsius: " + temp.getCelsius() + " °C");
            System.out.println("Fahrenheit: " + temp.getFahrenheit() + " °F");
            System.out.println("Internal Kelvin: " + temp.getKelvin() + " K");

        }
    }
