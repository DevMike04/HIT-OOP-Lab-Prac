import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class BankAccount {
    private String accountNumber;
    private double balance;
    private List<String> transactions; // Internal list

    public BankAccount(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
        this.transactions = new ArrayList<>();
        transactions.add("Account created with initial balance: $" + initialBalance);
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactions.add("Deposited: $" + amount);
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactions.add("Withdrew: $" + amount);
        } else {
            transactions.add("Failed withdrawal attempt: $" + amount);
        }
    }

    public double getBalance() {
        return balance;
    }

    // Returns an unmodifiable copy/view to prevent external modification of history
    public List<String> getTransactionHistory() {
        return Collections.unmodifiableList(transactions);
    }
}

class BankAccountTest {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount("ACC123", 500.0);
        acc.deposit(150.0);
        acc.withdraw(50.0);

        // Print transaction history
        for (String t : acc.getTransactionHistory()) {
            System.out.println(t);
        }

        // Trying to modify the list externally will throw an UnsupportedOperationException
        try {
            acc.getTransactionHistory().add("Hacked transaction");
        } catch (UnsupportedOperationException e) {
            System.out.println("\nSecurity check: Successfully blocked external modification of transaction history!");
        }
    }
}
