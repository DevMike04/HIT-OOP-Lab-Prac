import java.time.LocalDate;
import java.util.Objects;


public final class ImmutablePerson {
    private final String name;
    private final LocalDate birthDate;

    public ImmutablePerson(String name, LocalDate birthDate) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name must not be blank.");
        }
        this.name = name;
        this.birthDate = Objects.requireNonNull(birthDate, "Birth date must not be null.");
    }

    public String getName() {
        return name;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }
}
