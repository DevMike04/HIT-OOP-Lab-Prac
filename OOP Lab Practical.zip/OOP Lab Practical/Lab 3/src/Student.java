public class Student {
    private String name;
    private double marks;

    // Constructor
    public Student(String name, double marks) {
        this.name = name;
        setMarks(marks); // Uses setter to ensure validation runs during construction
    }

    // Getter for Name
    public String getName() {
        return name;
    }

    // Setter for Name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for Marks
    public double getMarks() {
        return marks;
    }

    // Setter with validation (rejects invalid marks outside 0-100)
    public void setMarks(double marks) {
        if (marks >= 0 && marks <= 100) {
            this.marks = marks;
        } else {
            System.out.println("Invalid marks (" + marks + "). Must be between 0 and 100. Marks not updated.");
        }
    }

    // Computes and returns the grade dynamically without storing it in a field
    public char getGrade() {
        if (marks >= 90) {
            return 'A';
        } else if (marks >= 80) {
            return 'B';
        } else if (marks >= 70) {
            return 'C';
        } else {
            return 'F';
        }
    }
}

class Student_Test {
    private Student_Test() {
    }

    public static void main(String[] args) {
        Student student = new Student("Alice", 85.5);
        System.out.println(student.getName() + " marks: " + student.getMarks() + ", Grade: " + student.getGrade());

        // Attempting to set invalid marks
        student.setMarks(105.0); // Rejected
        System.out.println("After invalid update, marks remain: " + student.getMarks());
    }

    static Student_Test createStudent_Test() {
        return new Student_Test();
    }
}
