import java.util.InputMismatchException;
import java.util.Scanner;

public class DivisionHandler {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter numerator (integer): ");
            int num1 = scanner.nextInt();

            System.out.print("Enter denominator (integer): ");
            int num2 = scanner.nextInt();

            int result = num1 / num2;
            System.out.println("Result: " + num1 + " / " + num2 + " = " + result);

        } catch (InputMismatchException e) {
            System.out.println("Error: Please enter valid whole numbers only.");
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is undefined.");
        } finally {
            scanner.close();
            System.out.println("Scanner closed successfully.");
        }
    }
}