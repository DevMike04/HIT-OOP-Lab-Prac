// Custom Unchecked/Runtime Exception
class InsufficientFundsException extends RuntimeException {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

class BankAccount {
    private String accountNumber;
    private double balance;

    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Refactored withdraw method throwing an exception on failure
    public void withdraw(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be greater than zero.");
        }
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient funds! Balance: $" + balance + ", Attempted: $" + amount);
        }
        balance -= amount;
        System.out.println("Successfully withdrew $" + amount + ". New balance: $" + balance);
    }
}

class BankAccountExceptionTest {
    public static void main(String[] args) {
        BankAccount account = new BankAccount("ACC100", 250.0);

        try {
            account.withdraw(100.0); // Successful
            account.withdraw(300.0); // Throws InsufficientFundsException
        } catch (InsufficientFundsException e) {
            System.out.println("Transaction Failed: " + e.getMessage());
        }
    }
}