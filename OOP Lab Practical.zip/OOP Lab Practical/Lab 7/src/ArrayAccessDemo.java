public class ArrayAccessDemo {
    public static void getElement(int[] array, int index) {
        try {
            System.out.println("Element at index " + index + ": " + array[index]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught Exception: Index " + index + " is out of bounds for an array of length " + array.length);
        }
    }

    public static void main(String[] args) {
        int[] numbers = {10, 20, 30, 40, 50};

        System.out.println("Accessing valid index:");
        getElement(numbers, 2); // Valid index

        System.out.println("\nAccessing invalid index:");
        getElement(numbers, 8); // Throws ArrayIndexOutOfBoundsException
    }
}
