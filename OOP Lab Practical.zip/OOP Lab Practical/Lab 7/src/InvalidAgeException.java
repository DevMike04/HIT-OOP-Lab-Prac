// Custom Checked Exception
public class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

class AgeValidator {
    // Method declares that it throws a checked exception
    public static void validateAge(int age) throws InvalidAgeException {
        if (age < 0 || age > 120) {
            throw new InvalidAgeException("Invalid age: " + age + ". Must be between 0 and 120.");
        }
        System.out.println("Age " + age + " is valid.");
    }

    public static void main(String[] args) {
        try {
            validateAge(25);  // Valid
            validateAge(150); // Triggers InvalidAgeException
        } catch (InvalidAgeException e) {
            System.out.println("Caught Checked Exception: " + e.getMessage());
        }
    }
}