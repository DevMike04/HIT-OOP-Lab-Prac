public class FinallyDemo {
    public static int testMethod() {
        try {
            System.out.println("1. Inside try block. Executing return statement.");
            return 10;
        } finally {
            System.out.println("2. Inside finally block. This always executes!");
        }
    }

    public static void main(String[] args) {
        int result = testMethod();
        System.out.println("3. Returned value received in main: " + result);
    }
}