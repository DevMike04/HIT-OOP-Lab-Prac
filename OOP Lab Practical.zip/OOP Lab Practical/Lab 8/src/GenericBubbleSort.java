import java.util.Arrays;

public class GenericBubbleSort {

    // Generic bubble sort method for any type implementing Comparable
    public static <T extends Comparable<T>> void bubbleSort(T[] arr) {
        int n = arr.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    // Swap elements
                    T temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped) break; // Optimization if already sorted
        }
    }

    public static void main(String[] args) {
        // Test with Integer[]
        Integer[] intArr = {64, 34, 25, 12, 22, 11, 90};
        bubbleSort(intArr);
        System.out.println("Sorted Integers: " + Arrays.toString(intArr));

        // Test with String[]
        String[] strArr = {"banana", "apple", "cherry", "date"};
        bubbleSort(strArr);
        System.out.println("Sorted Strings: " + Arrays.toString(strArr));
    }
}