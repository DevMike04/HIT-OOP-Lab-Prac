import java.util.*;

public class WordFrequencyCounter {
    public static void main(String[] args) {
        String paragraph = "Java is a popular programming language. Java is widely used " +
                "for enterprise applications, and programming in Java is fun.";

        // Clean punctuation and split into words
        String[] words = paragraph.toLowerCase().replaceAll("[^a-zA-Z ]", "").split("\\s+");

        // Count frequencies using a Map
        Map<String, Integer> frequencyMap = new HashMap<>();
        for (String word : words) {
            if (!word.isEmpty()) {
                frequencyMap.put(word, frequencyMap.getOrDefault(word, 0) + 1);
            }
        }

        // Sort the map entries by frequency descending
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(frequencyMap.entrySet());
        sortedEntries.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));

        // Print results
        System.out.println("Word Frequencies (Descending Order):");
        for (Map.Entry<String, Integer> entry : sortedEntries) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}