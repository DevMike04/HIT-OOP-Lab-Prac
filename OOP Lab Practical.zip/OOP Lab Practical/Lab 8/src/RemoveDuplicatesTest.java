import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicatesTest {
    public static void main(String[] args) {
        List<String> namesWithDuplicates = Arrays.asList(
                "Michael", "Trevor", "Charlie", "Michael", "David", "Trevor", "Eve"
        );

        System.out.println("Original List with Duplicates: " + namesWithDuplicates);

        // Pass the list to a LinkedHashSet to remove duplicates while preserving order
        Set<String> uniqueNames = new LinkedHashSet<>(namesWithDuplicates);

        System.out.println("Unique Names (Set): " + uniqueNames);
    }
}
