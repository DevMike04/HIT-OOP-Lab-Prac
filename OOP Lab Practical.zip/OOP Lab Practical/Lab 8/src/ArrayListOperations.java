import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListOperations {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();

        // Storing 10 integers
        int[] inputValues = {12, 45, 7, 89, 23, 56, 34, 90, 11, 65};
        for (int num : inputValues) {
            numbers.add(num);
        }

        // 1. Calculate Sum
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }

        // 2. Find Maximum
        int max = Collections.max(numbers);

        // 3. Print list in reverse order
        // Create a copy or reverse in-place for printing
        List<Integer> reversedList = new ArrayList<>(numbers);
        Collections.reverse(reversedList);

        System.out.println("Original List: " + numbers);
        System.out.println("Sum of elements: " + sum);
        System.out.println("Maximum element: " + max);
        System.out.println("List in reverse order: " + reversedList);
    }
}