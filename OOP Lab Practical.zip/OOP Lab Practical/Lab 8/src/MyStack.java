import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;

class MyStack<T> {
    private List<T> list = new ArrayList<>();

    // Push an item onto the stack
    public void push(T item) {
        list.add(item);
    }

    // Pop and return the top item from the stack
    public T pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return list.remove(list.size() - 1);
    }

    // Peek at the top item without removing it
    public T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return list.get(list.size() - 1);
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return list.isEmpty();
    }
}

class StackTest {
    public static void main(String[] args) {
        MyStack<String> stack = new MyStack<>();

        stack.push("Java");
        stack.push("Python");
        stack.push("C++");

        System.out.println("Top element (peek): " + stack.peek()); // C++
        System.out.println("Popped: " + stack.pop());               // C++
        System.out.println("Popped: " + stack.pop());               // Python
        System.out.println("Is stack empty? " + stack.isEmpty());   // false
    }
}
