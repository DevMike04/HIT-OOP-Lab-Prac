public interface Flyable {
    void fly();
}

class Bird implements Flyable {
    @Override
    public void fly() {
        System.out.println("Bird flies by flapping its feathered wings.");
    }
}

class Aeroplane implements Flyable {
    @Override
    public void fly() {
        System.out.println("Aeroplane flies using jet engines and aerodynamic lift.");
    }
}

class FlyableTest {
    public static void main(String[] args) {
        Flyable[] flyers = {
                new Bird(),
                new Aeroplane()
        };

        for (Flyable f : flyers) {
            f.fly(); // Polymorphic behavior across completely unrelated types
        }
    }
}
