abstract class Account {
    protected String accountNumber;
    protected double balance;

    public Account(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    // Concrete method shared by all accounts
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited $" + amount + ". New balance: $" + balance);
        }
    }

    // Abstract method forcing subclasses to define their specific fee structure
    public abstract void monthlyFee();

    public double getBalance() {
        return balance;
    }
}

class SavingsAccount extends Account {
    public SavingsAccount(String accountNumber, double initialBalance) {
        super(accountNumber, initialBalance);
    }

    @Override
    public void monthlyFee() {
        double fee = 5.0; // Fixed low maintenance fee for savings
        balance -= fee;
        System.out.println("Savings monthly fee applied: $" + fee + ". Balance: $" + balance);
    }
}

class CurrentAccount extends Account {
    public CurrentAccount(String accountNumber, double initialBalance) {
        super(accountNumber, initialBalance);
    }

    @Override
    public void monthlyFee() {
        double fee = 15.0; // Higher fee for corporate/current accounts
        balance -= fee;
        System.out.println("Current account monthly fee applied: $" + fee + ". Balance: $" + balance);
    }
}

class AccountTest {
    public static void main(String[] args) {
        Account savings = new SavingsAccount("SA101", 1000.0);
        Account current = new CurrentAccount("CA202", 2500.0);

        savings.deposit(200.0);
        savings.monthlyFee();

        System.out.println("---");

        current.deposit(500.0);
        current.monthlyFee();
    }
}
