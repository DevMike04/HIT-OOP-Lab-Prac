import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Student implements Comparable<Student> {
    String name;
    double marks;

    public Student(String name, double marks) {
        this.name = name;
        this.marks = marks;
    }

    // Natural sorting order: alphabetical by name
    @Override
    public int compareTo(Student other) {
        return this.name.compareTo(other.name);
    }

    @Override
    public String toString() {
        return name + " (Marks: " + marks + ")";
    }
}

// Custom Comparator to sort by marks (highest first)
class StudentMarksComparator implements Comparator<Student> {
    @Override
    public int compare(Student s1, Student s2) {
        return Double.compare(s2.marks, s1.marks);
    }
}

class SortingTest {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        students.add(new Student("Charlie", 82.5));
        students.add(new Student("Alice", 95.0));
        students.add(new Student("Bob", 78.0));

        // 1. Natural Sorting using Comparable (by Name)
        Collections.sort(students);
        System.out.println("Sorted by Name (Natural Ordering):");
        for (Student s : students) {
            System.out.println(s);
        }

        // 2. Custom Sorting using Comparator (by Marks)
        students.sort(new StudentMarksComparator());
        System.out.println("\nSorted by Marks (Custom Comparator):");
        for (Student s : students) {
            System.out.println(s);
        }
    }
}
