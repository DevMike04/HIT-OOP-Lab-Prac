interface InterfaceA {
    default void hello() {
        System.out.println("Hello from Interface A");
    }
}

interface InterfaceB {
    default void hello() {
        System.out.println("Hello from Interface B");
    }
}

class MultiInterfaceClass implements InterfaceA, InterfaceB {
    // Conflict resolution: Java requires an explicit override when inheriting
    // multiple default methods with identical signatures.
    @Override
    public void hello() {
        // Explicitly invoke InterfaceA's default implementation
        InterfaceA.super.hello();

        // Alternatively, invoke InterfaceB's or combine/custom-implement it
        InterfaceB.super.hello();

        System.out.println("Hello overridden in MultiInterfaceClass!");
    }
}

class DefaultMethodConflictTest {
    public static void main(String[] args) {
        MultiInterfaceClass obj = new MultiInterfaceClass();
        obj.hello();
    }
}