import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

class Book {
    private String isbn;
    private String title;

    public Book(String isbn, String title) {
        this.isbn = isbn;
        this.title = title;
    }

    public String getIsbn() {
        return isbn;
    }

    // Override equals based exclusively on ISBN
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return Objects.equals(isbn, book.isbn);
    }

    // Override hashCode consistently based on ISBN
    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }

    @Override
    public String toString() {
        return "Book{isbn='" + isbn + "', title='" + title + "'}";
    }
}

class HashSetDuplicateTest {
    public static void main(String[] args) {
        Set<Book> bookSet = new HashSet<>();

        Book b1 = new Book("978-0134685991", "Effective Java");
        Book b2 = new Book("978-0321356680", "Clean Code");
        // Duplicate ISBN with b1, but a different title object string
        Book b3 = new Book("978-0134685991", "Effective Java (Duplicate Entry)");

        bookSet.add(b1);
        bookSet.add(b2);
        boolean addedDuplicate = bookSet.add(b3); // Should return false

        System.out.println("Was duplicate b3 added? " + addedDuplicate);
        System.out.println("Total unique books in HashSet: " + bookSet.size());
        System.out.println("Contents: " + bookSet);
    }
}
