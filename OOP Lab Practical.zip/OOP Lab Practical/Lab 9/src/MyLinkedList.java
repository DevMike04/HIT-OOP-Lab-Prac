import java.util.Iterator;
import java.util.NoSuchElementException;

class MyLinkedList<T> implements Iterable<T> {
    private Node<T> head;

    // Private static nested Node class
    private static class Node<T> {
        T data;
        Node<T> next;

        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    public void add(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Provides an iterator so the class works in a for-each loop
    @Override
    public Iterator<T> iterator() {
        return new ListIterator();
    }

    // Inner Iterator class (has access to outer class or instance context)
    private class ListIterator implements Iterator<T> {
        private Node<T> current = head;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T data = current.data;
            current = current.next;
            return data;
        }
    }
}

class LinkedListTest {
    public static void main(String[] args) {
        MyLinkedList<String> list = new MyLinkedList<>();
        list.add("Java");
        list.add("Data Structures");
        list.add("And");
        list.add("Algorithms");

        // Works in a for-each loop because it implements Iterable
        System.out.println("Iterating through custom LinkedList:");
        for (String item : list) {
            System.out.println(item);
        }
    }
}