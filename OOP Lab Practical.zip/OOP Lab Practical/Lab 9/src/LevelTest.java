enum Level {
    LOW, MEDIUM, HIGH
}

public class LevelTest {
    public static void printAdvice(Level level) {
        // Modern Java switch expression
        String advice = switch (level) {
            case LOW -> "Advice: Take it easy, low priority task.";
            case MEDIUM -> "Advice: Moderate focus required, keep a steady pace.";
            case HIGH -> "Advice: Urgent! High priority, tackle this immediately.";
        };
        System.out.println(level + ": " + advice);
    }

    public static void main(String[] args) {
        printAdvice(Level.LOW);
        printAdvice(Level.MEDIUM);
        printAdvice(Level.HIGH);
    }
}
