import java.util.LinkedHashMap;
import java.util.Map;

enum Coin {
    QUARTER(25),
    DIME(10),
    NICKEL(5),
    PENNY(1);

    private final int value; // Value in cents

    Coin(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    // Greedy algorithm to return the fewest coins for a given amount in cents
    public static Map<Coin, Integer> getFewestCoins(int cents) {
        Map<Coin, Integer> change = new LinkedHashMap<>();

        for (Coin coin : Coin.values()) {
            if (cents >= coin.value) {
                int count = cents / coin.value; // Number of coins of this denomination
                cents %= coin.value;            // Remaining cents
                change.put(coin, count);
            }
        }
        return change;
    }
}

public class CoinTest {
    public static void main(String[] args) {
        int amountInCents = 87; // e.g., $0.87
        Map<Coin, Integer> result = Coin.getFewestCoins(amountInCents);

        System.out.println("Fewest coins for " + amountInCents + " cents ($0.87):");
        for (Map.Entry<Coin, Integer> entry : result.entrySet()) {
            System.out.println(entry.getValue() + " x " + entry.getKey().name() + " (" + entry.getKey().getValue() + "¢)");
        }
    }
}
