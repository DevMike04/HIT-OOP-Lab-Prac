// Defining a record
record Student(String name, int age) {}

public class RecordTest {
    public static void main(String[] args) {
        Student s1 = new Student("Kuda", 22);
        Student s2 = new Student("Kuda", 22);
        Student s3 = new Student("Bob", 24);

        // 1. Print the record (uses built-in descriptive toString())
        System.out.println("Student 1: " + s1);

        // 2. Compare two equal records
        System.out.println("s1 equals s2? " + s1.equals(s2)); // true (value-based equality)
        System.out.println("s1 equals s3? " + s1.equals(s3)); // false

        // 3. Read a component using the auto-generated accessor methods
        System.out.println("Name of s1: " + s1.name());
        System.out.println("Age of s1: " + s1.age());
    }
}
