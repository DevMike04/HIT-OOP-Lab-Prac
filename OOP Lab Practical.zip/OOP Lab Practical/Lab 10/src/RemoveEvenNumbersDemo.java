import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class RemoveEvenNumbersDemo {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
        System.out.println("Original list: " + numbers);

        // Define a Predicate that checks if a number is even
        Predicate<Integer> isEven = n -> n % 2 == 0;

        // Remove all even numbers using removeIf
        numbers.removeIf(isEven);

        System.out.println("List after removing evens: " + numbers);
    }
}
