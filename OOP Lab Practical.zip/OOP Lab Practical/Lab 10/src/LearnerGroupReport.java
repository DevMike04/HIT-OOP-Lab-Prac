import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

record Learner(String name, String gradeBand) {}

public class LearnerGroupReport {
    public static void main(String[] args) {
        Path path = Path.of("learners.csv");

        try {
            // Read lines from CSV (skipping header row: name,gradeBand)
            List<Learner> learners = Files.lines(path)
                    .skip(1)
                    .map(line -> {
                        String[] parts = line.split(",");
                        return new Learner(parts[0].trim(), parts[1].trim());
                    })
                    .collect(Collectors.toList());

            // Group learners by grade band using Collectors.groupingBy
            Map<String, List<Learner>> groupedByBand = learners.stream()
                    .collect(Collectors.groupingBy(Learner::gradeBand));

            // Write one report file per band
            for (Map.Entry<String, List<Learner>> entry : groupedByBand.entrySet()) {
                String band = entry.getKey();
                List<Learner> bandLearners = entry.getValue();

                Path reportPath = Path.of("report_band_" + band + ".txt");
                List<String> namesList = bandLearners.stream()
                        .map(Learner::name)
                        .collect(Collectors.toList());

                // Write the list of learner names to the band-specific report file
                Files.write(reportPath, namesList);
                System.out.println("Generated report file '" + reportPath + "' with " + bandLearners.size() + " learners.");
            }

        } catch (IOException e) {
            System.out.println("Error processing CSV file: " + e.getMessage());
            System.out.println("Note: Ensure 'learners.csv' exists with a header row and format: Name,GradeBand");
        }
    }
}