import java.util.Arrays;
import java.util.List;

record StudentRecord(String name, double score) {}

public class StudentStream {
    public static void main(String[] args) {
        List<StudentRecord> students = Arrays.asList(
                new StudentRecord("Michael", 85.0),
                new StudentRecord("Mary", 62.5),
                new StudentRecord("Chantelle", 90.0),
                new StudentRecord("Nokutenda", 74.5),
                new StudentRecord("Tinotenda", 88.0)
        );

        // 1. Calculate the class average score
        double classAverage = students.stream()
                .mapToDouble(StudentRecord::score)
                .average()
                .orElse(0.0);

        System.out.println("Class Average Score: " + classAverage);
        System.out.println("\nStudents scoring above average (sorted alphabetically):");

        // 2. Filter students above average, map to names, sort, and print
        students.stream()
                .filter(s -> s.score() > classAverage)
                .map(StudentRecord::name)
                .sorted()
                .forEach(System.out::println);
    }
}