import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileWriteReadDemo {
    public static void main(String[] args) {
        String filename = "user_lines.txt";
        Scanner scanner = new Scanner(System.in);

        // Writing 5 lines typed by the user to a file
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            System.out.println("Please enter 5 lines of text:");
            for (int i = 1; i <= 5; i++) {
                System.out.print("Line " + i + ": ");
                String line = scanner.nextLine();
                writer.println(line);
            }
            System.out.println("\nSuccessfully wrote 5 lines to '" + filename + "'.\n");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }

        // Reading the lines back from the file
        System.out.println("--- Reading back from file ---");
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }

        scanner.close();
    }
}