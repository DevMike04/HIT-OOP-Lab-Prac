import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileStatsDemo {
    public static void main(String[] args) {
        String filename = "sample.txt"; // Make sure sample.txt exists in your directory
        long lineCount = 0;
        long wordCount = 0;
        long charCount = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lineCount++;
                charCount += line.length() + 1; // +1 accounts for the newline character

                if (!line.trim().isEmpty()) {
                    String[] words = line.trim().split("\\s+");
                    wordCount += words.length;
                }
            }

            System.out.println("File Statistics for '" + filename + "':");
            System.out.println("Lines: " + lineCount);
            System.out.println("Words: " + wordCount);
            System.out.println("Characters: " + charCount);

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}