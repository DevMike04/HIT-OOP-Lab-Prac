public class Circle {
    double radius;
    private static int circleCount = 0; // Static counter for tracking instances

    // No-argument constructor defaulting radius to 1.0
    public Circle() {
        this.radius = 1.0;
        circleCount++;
    }

    // Parameterized constructor taking radius
    public Circle(double radius) {
        this.radius = radius;
        circleCount++;
    }

    // Static getter to retrieve total circles created
    public static int getCircleCount() {
        return circleCount;
    }
}

class CircleTest {
    static void main() {
        Circle c1 = new Circle();       // Uses no-arg constructor (radius = 1.0)
        Circle c2 = new Circle(5.5);    // Uses parameterized constructor
        Circle c3 = new Circle(10.0);   // Uses parameterized constructor

        System.out.println("Circle 1 radius: " + c1.radius);
        System.out.println("Circle 2 radius: " + c2.radius);
        System.out.println("Total circles created: " + Circle.getCircleCount());
    }
}
