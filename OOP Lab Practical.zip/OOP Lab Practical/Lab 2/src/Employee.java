public class Employee {
    private static int idCounter = 1000; // Shared static counter for unique IDs
    private final int employeeId;
    private final String name;
    private final String department;
    private final double salary;

    // Overloaded Constructor 1: Name only
    public Employee(String name) {
        this.employeeId = idCounter++;
        this.name = name;
        this.department = "General";
        this.salary = 35000.0;
    }

    // Overloaded Constructor 2: Name and department
    public Employee(String name, String department) {
        this.employeeId = idCounter++;
        this.name = name;
        this.department = department;
        this.salary = 50000.0;
    }

    // Overloaded Constructor 3: Name, department, and salary
    public Employee(String name, String department, double salary) {
        this.employeeId = idCounter++;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    // Copy Constructor: Creates a new employee by copying an existing one's details
    public Employee(Employee other) {
        this.employeeId = idCounter++; // Assigns a new unique ID for the copy
        this.name = other.name;
        this.department = other.department;
        this.salary = other.salary;
    }

    public void display() {
        System.out.println("ID: " + employeeId + ", Name: " + name + ", Dept: " + department + ", Salary: $" + salary);
    }
}

class EmployeeTest {
    static void main() {
        Employee emp1 = new Employee("Alice");
        Employee emp2 = new Employee("Bob", "Engineering");
        Employee emp3 = new Employee("Charlie", "Finance", 75000.0);

        // Using the copy constructor
        Employee emp4 = new Employee(emp3);

        emp1.display();
        emp2.display();
        emp3.display();
        System.out.println("-- Copied Employee --");
        emp4.display();
    }
}
