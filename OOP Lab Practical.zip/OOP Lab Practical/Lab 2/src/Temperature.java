public class Temperature {
    private final double celsius;

    // Private constructor blocks direct instantiation via 'new Temperature(...)'
    private Temperature(double celsius) {
        this.celsius = celsius;
    }

    // Static factory method for Celsius
    public static Temperature fromCelsius(double celsius) {
        return new Temperature(celsius);
    }

    // Static factory method for Fahrenheit
    public static Temperature fromFahrenheit(double fahrenheit) {
        double convertedCelsius = (fahrenheit - 32) * 5.0 / 9.0;
        return new Temperature(convertedCelsius);
    }

    public double getCelsius() {
        return celsius;
    }

    public double getFahrenheit() {
        return celsius * 9.0 / 5.0 + 32;
    }
}

class TemperatureTest {
    static void main() {
        // Clear, intent-revealing instantiation
        Temperature t1 = Temperature.fromCelsius(25.0);
        Temperature t2 = Temperature.fromFahrenheit(77.0);

        System.out.println("t1 Celsius: " + t1.getCelsius() + "°C | Fahrenheit: " + t1.getFahrenheit() + "°F");
        System.out.println("t2 Celsius: " + t2.getCelsius() + "°C | Fahrenheit: " + t2.getFahrenheit() + "°F");
    }
}
