public class BlockDemo {
    static {
        System.out.println("1. Static Block 1 executed.");
    }

    // Instance Block 1
    {
        System.out.println("3. Instance Block 1 executed.");
    }

    // Static Block 2
    static {
        System.out.println("2. Static Block 2 executed.");
    }

    // Instance Block 2
    {
        System.out.println("4. Instance Block 2 executed.");
    }

    // Constructor
    public BlockDemo() {
        System.out.println("5. Constructor executed.");
    }
}

class BlockTest {
    static void main() {
        System.out.println("Main method started.");
        BlockDemo obj = new BlockDemo();
    }
}
