import java.time.LocalDate;

public abstract class LibraryItem implements Borrowable {
    private String id;
    private String title;
    private boolean available;
    private LocalDate dueDate;
    private String borrowerId;

    public LibraryItem(String id, String title) {
        this.id = id;
        this.title = title;
        this.available = true;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public String getBorrowerId() { return borrowerId; }
    public void setBorrowerId(String borrowerId) { this.borrowerId = borrowerId; }

    public abstract int loanPeriodDays();

    @Override
    public void borrowItem(Member member) throws ItemNotAvailableException, MemberLimitExceededException {
        if (!available) {
            throw new ItemNotAvailableException("Item [" + id + "] '" + title + "' is currently checked out.");
        }
        if (!member.canBorrow()) {
            throw new MemberLimitExceededException("Member " + member.getName() + " has reached the maximum limit of 3 active loans.");
        }
        this.available = false;
        this.borrowerId = member.getId();
        this.dueDate = LocalDate.now().plusDays(loanPeriodDays());
        member.addLoan(this.id);
    }

    @Override
    public void giveBack(Member member) {
        this.available = true;
        this.borrowerId = null;
        this.dueDate = null;
        member.removeLoan(this.id);
    }

    @Override
    public String toString() {
        return "[" + id + "] " + title + " (" + getClass().getSimpleName() + ") - Available: " + available
                + (dueDate != null ? " | Due: " + dueDate : "");
    }
}
