public class Book extends LibraryItem {
    private String author;

    public Book(String id, String title, String author) {
        super(id, title);
        this.author = author;
    }

    public String getAuthor() { return author; }

    @Override
    public int loanPeriodDays() {
        return 14; // Books have a 2-week loan period
    }
}