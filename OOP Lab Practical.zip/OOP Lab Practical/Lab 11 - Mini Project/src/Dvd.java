public class Dvd extends LibraryItem {
    private int durationMinutes;

    public Dvd(String id, String title, int durationMinutes) {
        super(id, title);
        this.durationMinutes = durationMinutes;
    }

    public int getDurationMinutes() { return durationMinutes; }

    @Override
    public int loanPeriodDays() {
        return 7; // DVDs have a 1-week loan period
    }
}