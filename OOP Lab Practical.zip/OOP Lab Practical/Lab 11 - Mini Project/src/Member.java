import java.util.ArrayList;
import java.util.List;

public class Member {
    private String id;
    private String name;
    private List<String> borrowedItemIds;

    public Member(String id, String name) {
        this.id = id;
        this.name = name;
        this.borrowedItemIds = new ArrayList<>();
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public List<String> getBorrowedItemIds() { return borrowedItemIds; }

    public boolean canBorrow() {
        return borrowedItemIds.size() < 3; // Maximum 3 loans per member
    }

    public void addLoan(String itemId) {
        borrowedItemIds.add(itemId);
    }

    public void removeLoan(String itemId) {
        borrowedItemIds.remove(itemId);
    }

    @Override
    public String toString() {
        return "Member [ID=" + id + ", Name=" + name + ", Active Loans Count=" + borrowedItemIds.size() + "]";
    }
}