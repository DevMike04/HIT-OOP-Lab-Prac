import java.io.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class LibrarySystemApp {
    private static final Map<String, LibraryItem> items;

    static {
        items = new HashMap<>();
    }

    private static final Map<String, Member> members = new HashMap<>();

    private static final String ITEMS_FILE = "items.csv";
    private static final String MEMBERS_FILE = "members.csv";

    static void main() {
        loadData();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n========================================");
            System.out.println("      LIBRARY MANAGEMENT SYSTEM         ");
            System.out.println("========================================");
            System.out.println("1. Add Item (Book / DVD)");
            System.out.println("2. Register Member");
            System.out.println("3. Borrow Item");
            System.out.println("4. Return Item");
            System.out.println("5. List Overdue Items");
            System.out.println("6. Search Items by Title (Streams)");
            System.out.println("7. Display All Items & Members");
            System.out.println("8. Exit & Save Data");
            System.out.print("Select an option (1-8): ");

            String input = scanner.nextLine();
            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number between 1 and 8.");
                continue;
            }

            switch (choice) {
                case 1 -> addItem(scanner);
                case 2 -> registerMember(scanner);
                case 3 -> borrowItem(scanner);
                case 4 -> returnItem(scanner);
                case 5 -> listOverdueItems();
                case 6 -> searchByTitle(scanner);
                case 7 -> displayAll();
                case 8 -> {
                    saveData();
                    running = false;
                    System.out.println("Data successfully saved. Goodbye!");
                }
                default -> System.out.println("Invalid choice. Please select between 1 and 8.");
            }
        }
        scanner.close();
    }

    private static void addItem(Scanner scanner) {
        System.out.print("Enter item type (1 for Book, 2 for DVD): ");
        String type = scanner.nextLine();
        System.out.print("Enter Item ID: ");
        String id = scanner.nextLine();
        if (items.containsKey(id)) {
            System.out.println("Error: Item ID already exists.");
            return;
        }
        System.out.print("Enter Title: ");
        String title = scanner.nextLine();

        if (type.equals("1")) {
            System.out.print("Enter Author: ");
            String author = scanner.nextLine();
            items.put(id, new Book(id, title, author));
            System.out.println("Book added successfully.");
        } else if (type.equals("2")) {
            System.out.print("Enter Duration (minutes): ");
            try {
                int duration = Integer.parseInt(scanner.nextLine());
                items.put(id, new Dvd(id, title, duration));
                System.out.println("DVD added successfully.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid duration format.");
            }
        } else {
            System.out.println("Invalid item type.");
        }
    }

    private static void registerMember(Scanner scanner) {
        System.out.print("Enter Member ID: ");
        String id = scanner.nextLine();
        if (members.containsKey(id)) {
            System.out.println("Error: Member ID already registered.");
            return;
        }
        System.out.print("Enter Member Name: ");
        String name = scanner.nextLine();
        members.put(id, new Member(id, name));
        System.out.println("Member registered successfully.");
    }

    private static void borrowItem(Scanner scanner) {
        System.out.print("Enter Member ID: ");
        String memberId = scanner.nextLine();
        Member member = members.get(memberId);
        if (member == null) {
            System.out.println("Member not found.");
            return;
        }

        System.out.print("Enter Item ID to borrow: ");
        String itemId = scanner.nextLine();
        LibraryItem item = items.get(itemId);
        if (item == null) {
            System.out.println("Item not found.");
            return;
        }

        try {
            item.borrowItem(member);
            System.out.println("Success! Item borrowed. Due date: " + item.getDueDate());
        } catch (ItemNotAvailableException | MemberLimitExceededException e) {
            System.out.println("Borrow failed: " + e.getMessage());
        }
    }

    private static void returnItem(Scanner scanner) {
        System.out.print("Enter Member ID returning the item: ");
        String memberId = scanner.nextLine();
        Member member = members.get(memberId);
        if (member == null) {
            System.out.println("Member not found.");
            return;
        }

        System.out.print("Enter Item ID to return: ");
        String itemId = scanner.nextLine();
        LibraryItem item = items.get(itemId);
        if (item == null) {
            System.out.println("Item not found.");
            return;
        }

        if (item.isAvailable() || (!itemId.equals(item.getBorrowerId()) && !member.getBorrowedItemIds().contains(itemId))) {
            System.out.println("Error: This item is not currently checked out by this member.");
            return;
        }

        item.giveBack(member);
        System.out.println("Item returned successfully.");
    }

    private static void listOverdueItems() {
        System.out.println("\n--- Overdue Items ---");
        LocalDate today = LocalDate.now();
        long count = items.values().stream()
                .filter(item -> !item.isAvailable() && item.getDueDate() != null && item.getDueDate().isBefore(today))
                .peek(item -> System.out.println(item + " [OVERDUE by " + java.time.temporal.ChronoUnit.DAYS.between(item.getDueDate(), today) + " days]"))
                .count();

        if (count == 0) {
            System.out.println("No overdue items found.");
        }
    }

    private static void searchByTitle(Scanner scanner) {
        System.out.print("Enter search keyword or title: ");
        String keyword = scanner.nextLine().toLowerCase();

        List<LibraryItem> results = items.values().stream()
                .filter(item -> item.getTitle().toLowerCase().contains(keyword))
                .collect(Collectors.toList());

        System.out.println("\n--- Search Results (" + results.size() + " found) ---");
        results.forEach(System.out::println);
    }

    private static void displayAll() {
        System.out.println("\n--- Library Catalog (" + items.size() + " items) ---");
        items.values().forEach(System.out::println);

        System.out.println("\n--- Registered Members (" + members.size() + " members) ---");
        members.values().forEach(System.out::println);
    }

    private static void saveData() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ITEMS_FILE))) {
            for (LibraryItem item : items.values()) {
                if (item instanceof Book b) {
                    writer.println("BOOK," + b.getId() + "," + b.getTitle() + "," + b.getAuthor() + "," + b.isAvailable() + "," + b.getDueDate() + "," + b.getBorrowerId());
                } else if (item instanceof Dvd d) {
                    writer.println("DVD," + d.getId() + "," + d.getTitle() + "," + d.getDurationMinutes() + "," + d.isAvailable() + "," + d.getDueDate() + "," + d.getBorrowerId());
                }
            }
        } catch (IOException e) {
            System.out.println("Error saving items: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(MEMBERS_FILE))) {
            for (Member m : members.values()) {
                String loans = String.join(";", m.getBorrowedItemIds());
                writer.println(m.getId() + "," + m.getName() + "," + loans);
            }
        } catch (IOException e) {
            System.out.println("Error saving members: " + e.getMessage());
        }
    }

    private static void loadData() {
        File itemsFile = new File(ITEMS_FILE);
        if (itemsFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(itemsFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    String type = parts[0];
                    String id = parts[1];
                    String title = parts[2];
                    if (type.equals("BOOK")) {
                        String author = parts[3];
                        Book book = new Book(id, title, author);
                        book.setAvailable(Boolean.parseBoolean(parts[4]));
                        if (!parts[5].isEmpty() && !parts[5].equals("null")) book.setDueDate(LocalDate.parse(parts[5]));
                        if (!parts[6].isEmpty() && !parts[6].equals("null")) book.setBorrowerId(parts[6]);
                        items.put(id, book);
                    } else if (type.equals("DVD")) {
                        int duration = Integer.parseInt(parts[3]);
                        Dvd dvd = new Dvd(id, title, duration);
                        dvd.setAvailable(Boolean.parseBoolean(parts[4]));
                        if (!parts[5].isEmpty() && !parts[5].equals("null")) dvd.setDueDate(LocalDate.parse(parts[5]));
                        if (!parts[6].isEmpty() && !parts[6].equals("null")) dvd.setBorrowerId(parts[6]);
                        items.put(id, dvd);
                    }
                }
            } catch (IOException e) {
                System.out.println("Error loading items: " + e.getMessage());
            }
        }

        File membersFile = new File(MEMBERS_FILE);
        if (membersFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(membersFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    String id = parts[0];
                    String name = parts[1];
                    Member member = new Member(id, name);
                    if (parts.length > 2 && !parts[2].isEmpty()) {
                        String[] loanIds = parts[2].split(";");
                        for (String lid : loanIds) {
                            if (!lid.isEmpty()) member.addLoan(lid);
                        }
                    }
                    members.put(id, member);
                }
            } catch (IOException e) {
                System.out.println("Error loading members: " + e.getMessage());
            }
        }
    }
}