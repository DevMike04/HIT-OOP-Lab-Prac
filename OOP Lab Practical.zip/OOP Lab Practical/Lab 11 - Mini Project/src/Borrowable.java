public interface Borrowable {
    void borrowItem(Member member) throws ItemNotAvailableException, MemberLimitExceededException;
    void giveBack(Member member);
}