public class Vehicle {
    public Vehicle() {
        System.out.println("1. Vehicle constructor called");
    }
}

class Car extends Vehicle {
    public Car() {
        super(); // Implicitly called by compiler if omitted
        System.out.println("2. Car constructor called");
    }
}

class ElectricCar extends Car {
    public ElectricCar() {
        super(); // Implicitly called by compiler if omitted
        System.out.println("3. ElectricCar constructor called");
    }
}

class MultilevelConstructorTest {
    public static void main(String[] args) {
        System.out.println("Instantiating ElectricCar:");
        ElectricCar myTesla = new ElectricCar();
    }
}
