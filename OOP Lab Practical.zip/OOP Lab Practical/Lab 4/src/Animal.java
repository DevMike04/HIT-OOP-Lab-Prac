public class Animal {
    String name;

    // Parameterized constructor only (No default no-arg constructor exists)
    public Animal(String name) {
        this.name = name;
    }
}

//  COMPILE ERROR IF WRITTEN LIKE THIS:
// class Dog extends Animal {
//     // Compiler automatically inserts a default constructor:
//     // public Dog() {
//     //     super(); // Tries to call Animal's default constructor, which DOES NOT EXIST!
//     // }
// }

//  CORRECT WAY:
class Dog extends Animal {
    String breed;

    public Dog(String name, String breed) {
        super(name); // Explicitly calls the required parent constructor
        this.breed = breed;
    }
}
//Every subclass constructor must invoke a constructor of its superclass (either via super(...) explicitly or via an implicit super() call). If the superclass lacks a no-argument constructor, omitting super(arguments) results in a compile-time error.