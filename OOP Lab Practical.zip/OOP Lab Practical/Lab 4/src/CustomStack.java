import java.util.ArrayList;
import java.util.List;

public class CustomStack<T> {
    private final List<T> internalList = new ArrayList<>(); // Composition

    public void push(T item) {
        internalList.add(item);
    }

    public T pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return internalList.get(internalList.size() - 1);
}

    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return internalList.getLast();
    }

    public boolean isEmpty() {
        return internalList.isEmpty();
    }
}
