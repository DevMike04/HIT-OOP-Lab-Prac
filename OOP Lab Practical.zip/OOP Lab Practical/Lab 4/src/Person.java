public class Person {
    String name;
    int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void display() {
        System.out.print("Name: " + name + ", Age: " + age);
    }
}

class Student extends Person {
    String course;

    public Student(String name, int age, String course) {
        super(name, age); // Calls Person constructor
        this.course = course;
    }

    @Override
    public void display() {
        super.display();
        System.out.println(", Course: " + course);
    }
}

class Teacher extends Person {
    String subject;

    public Teacher(String name, int age, String subject) {
        super(name, age); // Calls Person constructor
        this.subject = subject;
    }

    @Override
    public void display() {
        super.display();
        System.out.println(", Subject: " + subject);
    }
}

class SchoolTest {
    public static void main(String[] args) {
        Student student = new Student("Michael", 20, "Software Engineering");
        Teacher teacher = new Teacher("Mr. Smith", 40, "Mathematics");

        System.out.println("--- Student Details ---");
        student.display();

        System.out.println("--- Teacher Details ---");
        teacher.display();
    }
}
